/*
 * Logic.cpp
 *
 *  Created on: 18 Dec 2022
 *      Author: tasneem
 */

#include "Logic.h"

Logic::Logic() {
	// TODO Auto-generated constructor stub

}

Logic::~Logic() {
	// TODO Auto-generated destructor stub
}

Logic::Logic(const Logic &other) {
	// TODO Auto-generated constructor stub

}

