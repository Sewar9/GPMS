/*
 * Logic.h
 *
 *  Created on: 18 Dec 2022
 *      Author: tasneem
 */

#ifndef LOGIC_H_
#define LOGIC_H_

class Logic {
public:
	Logic();
	virtual ~Logic();
	Logic(const Logic &other);
};

#endif /* LOGIC_H_ */
