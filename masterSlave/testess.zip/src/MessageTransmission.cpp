/*
 * MessageTransmission.cpp
 *
 *  Created on: 10 Jan 2023
 *      Author: sewar
 */
/*
#include "MessageTransmission.h"
#include "SlaveManager.h"

void send(int funcCode, int data){
	SlaveManager::getMessage(funcCode, data);

}
*/
