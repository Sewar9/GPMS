/*
 * MessageTransmission.h
 *
 *  Created on: 10 Jan 2023
 *      Author: sewar
 */
/*
#ifndef MessageTransmission
#define MessageTransmission

void send(int funcCode, int data);

#endif
*/
