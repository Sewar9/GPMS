/*
 * SlaveManager.cpp
 *
 *  Created on: 18 Dec 2022
 *      Author: tasneem
 */

#include "SlaveManager.h"
//#include "MessageTransmission.h"

SlaveManager::SlaveManager() {
	//this->trans_manager = new TransportManager();
	this->coils_table = new CoilsRegisters();
	this->discrete_table = new DiscreteInput();
	this->holding_regs_table = new HoldingRegisters();
	this->input_regs_table = new InputRegisters();
}

SlaveManager::~SlaveManager() {
	// TODO Auto-generated destructor stub
}
void SlaveManager::HandleMessage(MDSMessage &message){
	cout<<"this handle message x "<<endl;
	// SHOULD IMPLEMENT SWITCH CASE HERE !!

	switch(message.getFunctionCode()){
	case 3:
			cout<<"TBD Function code 3" <<endl;

			break;
	/*case 6:
			cout<<"TBD Function code 6" <<endl;
			break;
	case 10:
			cout<<"TBD Function code 10" <<endl;
	*/
	}
}

void SlaveManager::getMessage(uint8_t funcCode, std::vector<uint8_t> &data){
	MDSMessage mess;
	mess.setData(data);
	mess.setFunctionCode(funcCode);

	cout << "getMessage got called" << endl;
	HandleMessage(mess);
	return;
}


